/**
 * https://www.openssl.org/source/old/
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <openssl/evp.h>
#include <openssl/aes.h>
#define LOG_TAG "Main"
#include "../../../include/log_ext.h"

#define RC_AES_BLOCK (16)

typedef unsigned char uint8_t;

enum {
	AES_PADDING_DIS = 0,
	AES_PADDING_EN  = 1
};

const char *planText = "OpenSSL AES-CBC test";
const uint8_t RC_AES_KEY[RC_AES_BLOCK] = "1234567890123456"; //= { 0x5a, 0x39, 0x79, 0x36, 0x4e, 0x41, 0x77, 0x79, 0x6d, 0x56, 0x39, 0x73, 0x6c, 0x49, 0x39, 0x6d };
const uint8_t RC_AES_IV[RC_AES_BLOCK]  = "1234567890123456"; //;{ 0x70, 0x52, 0x33, 0x46, 0x78, 0x4c, 0x78, 0x5a, 0x6d, 0x39, 0x68, 0x54, 0x4e, 0x57, 0x67, 0x48 };

int aes_encrypt(const uint8_t *pPlainIn, int plainLength, uint8_t *pEncOut, int maxOutLen)
{

	int ret;
	int en_data_len = 0;
	int en_pad_len = 0;

	int alias = (plainLength % RC_AES_BLOCK) ? 1 : 0;
	if (maxOutLen < (((plainLength/RC_AES_BLOCK)+alias)<<4)) {
		log_error("%s: buffer to small!", __FUNCTION__);
		return -1;
	}

	EVP_CIPHER_CTX ctx;
	EVP_CIPHER_CTX_init(&ctx);
	ret = EVP_EncryptInit_ex(&ctx, EVP_aes_128_cbc(), NULL, RC_AES_KEY, RC_AES_IV);
	if(ret != 1) {
		error("%s: EVP_EncryptInit_ex failed!", __FUNCTION__);
		return -1;
	}

	if (EVP_CIPHER_CTX_key_length(&ctx) != 16 || EVP_CIPHER_CTX_iv_length(&ctx) != 16) {
		error("%s: key/IV length failed!", __FUNCTION__);
		return -1;
	}

	EVP_CIPHER_CTX_set_padding(&ctx, AES_PADDING_EN);
	ret = EVP_EncryptUpdate(&ctx, pEncOut, &en_data_len, pPlainIn, plainLength);
	if(ret != 1) {
		error("%s: EVP_EncryptUpdate failed!", __FUNCTION__);
		return -1;
	}

	ret = EVP_EncryptFinal_ex(&ctx, pEncOut + en_data_len, &en_pad_len);
	if(ret != 1) {
		error("%s: EVP_EncryptFinal_ex failed!", __FUNCTION__);
		return -1;
	}

	return en_data_len + en_pad_len;
}

int aes_decrypt(const uint8_t *pEncIn, int encLength, uint8_t *pPlainOut, int maxOutLen)
{

	int ret;
	int de_data_len = 0;
	int de_pad_len = 0;
	int de_total_len = 0;

	if (maxOutLen < encLength) {
		log_error("%s: buffer to small!", __FUNCTION__);
		return -1;
	}

	EVP_CIPHER_CTX ctx;
	EVP_CIPHER_CTX_init(&ctx);
	ret = EVP_DecryptInit_ex(&ctx, EVP_aes_128_cbc(), NULL, RC_AES_KEY, RC_AES_IV);
    if(ret != 1) {
        log_error("%s: EVP_DecryptInit_ex failed!", __FUNCTION__);
        return -1;
    }

    EVP_CIPHER_CTX_set_padding(&ctx, AES_PADDING_EN);
    ret = EVP_DecryptUpdate(&ctx, pPlainOut, &de_data_len, pEncIn, encLength);
    if(ret != 1) {
        error("%s: EVP_DecryptUpdate failed!", __FUNCTION__);
        return -1;
    }

	ret = EVP_DecryptFinal_ex(&ctx, pPlainOut + de_data_len, &de_pad_len);
    if(ret != 1) {
        error("%s: EVP_DecryptFinal_ex failed!", __FUNCTION__);
        return -1;
    }

	return de_data_len + de_pad_len;
}

int main(void)
{
	int ret;
	uint8_t envOut[128] = { 0 };
	ret = aes_encrypt(planText, strlen(planText), envOut, sizeof(envOut));
	log_info("aes_encrypt len: %d", ret);
	dump(envOut, ret);

	uint8_t plainOut[128] = { 0 };
	ret = aes_decrypt(envOut, ret, plainOut, sizeof(plainOut));
	log_info("\naes_decrypt len: %d", ret);
	log_info("plainOut: %s", plainOut);
	return 0;
}

