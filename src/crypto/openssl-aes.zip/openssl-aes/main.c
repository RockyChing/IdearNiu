/**
 * https://www.openssl.org/source/old/
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <aes/evp.h>
#include <aes/aes.h>
#define LOG_TAG "Main"
#include "../../../include/log_ext.h"

typedef unsigned char uint8_t;

enum {
	AES_PADDING_DIS = 0,
	AES_PADDING_EN  = 1
};

const uint8_t RC_AES_KEY[AES_BLOCK_SIZE] = "1234567890123456"; //= { 0x5a, 0x39, 0x79, 0x36, 0x4e, 0x41, 0x77, 0x79, 0x6d, 0x56, 0x39, 0x73, 0x6c, 0x49, 0x39, 0x6d };
const uint8_t RC_AES_IV[AES_BLOCK_SIZE]  = "1234567890123456"; //;{ 0x70, 0x52, 0x33, 0x46, 0x78, 0x4c, 0x78, 0x5a, 0x6d, 0x39, 0x68, 0x54, 0x4e, 0x57, 0x67, 0x48 };

/**
 * 02f8c758efea03bea3a5eae865d1d99b
 * 7ddac0dfe5374499f88b154b38226acd
 */
const char *planText = "OpenSSL AES-CBC test";

/**
 * c59516783e5734a25244bc846d33d53c4dc6874c1b93f0e36ee4ec78992534a2e
 * f032d15a48ae3cc5e3c8afccbb7a74b88cb1c9105464480ad5e0968c4818f4eaf
 * 82e750e2da6f05d58205a9a41db7b854ef4bf344ec64088e423dc64d00e7b0822
 * 502bbea6e4b8c7d36db7a0b7f2f6698843c90538cfbcaaa708ac2d9cbce8a1dde
 * 5fb5310b96e3bc1264160347619d4ede5fd5a1704b185762b7155f54077bdc5b0
 * b3e301e322e81143419f201647b9b40f8ff07352a9385920dd5a9abe8ab9f0de3
 * c42c09c62c03662e49361b7db0c0eb71bb5aaf0aae00f16a5780f7ecbd9ccd654
 * 937848c3dc13a47566186308c
 */
const char *planText2 = "AES 对称加密：请在这里输入您要加密的字符串，选择相应的算法模式、密钥长度、密钥、密钥偏移量、补码方式，以及加密结果编码方式，然后点击下方的“加密”按钮。";

int aes_encrypt(const uint8_t *pPlainIn, int plainLength, uint8_t *pEncOut, int maxOutLen)
{

	int ret;
	int en_data_len = 0;
	int en_pad_len = 0;

	int alias = (plainLength % AES_BLOCK_SIZE) ? 1 : 0;
	if (maxOutLen < (((plainLength/AES_BLOCK_SIZE)+alias)<<4)) {
		log_error("%s: buffer to small!", __FUNCTION__);
		return -1;
	}

	EVP_CIPHER_CTX ctx;
	EVP_CIPHER_CTX_init(&ctx);
	ret = EVP_EncryptInit_ex(&ctx, EVP_aes_128_cbc(), NULL, RC_AES_KEY, RC_AES_IV);
	if(ret != 1) {
		log_error("%s: EVP_EncryptInit_ex failed!", __FUNCTION__);
		return -1;
	}

	if (EVP_CIPHER_CTX_key_length(&ctx) != 16 || EVP_CIPHER_CTX_iv_length(&ctx) != 16) {
		log_error("%s: key/IV length failed!", __FUNCTION__);
		return -1;
	}

	EVP_CIPHER_CTX_set_padding(&ctx, AES_PADDING_EN);
	ret = EVP_EncryptUpdate(&ctx, pEncOut, &en_data_len, pPlainIn, plainLength);
	if(ret != 1) {
		log_error("%s: EVP_EncryptUpdate failed!", __FUNCTION__);
		return -1;
	}

	ret = EVP_EncryptFinal_ex(&ctx, pEncOut + en_data_len, &en_pad_len);
	if(ret != 1) {
		log_error("%s: EVP_EncryptFinal_ex failed!", __FUNCTION__);
		return -1;
	}

	EVP_CIPHER_CTX_cleanup(&ctx);
	return en_data_len + en_pad_len;
}

int aes_decrypt(const uint8_t *pEncIn, int encLength, uint8_t *pPlainOut, int maxOutLen)
{
	int ret;
	int de_data_len = 0;
	int de_pad_len = 0;

	if (maxOutLen < encLength) {
		log_error("%s: buffer to small!", __FUNCTION__);
		return -1;
	}

	EVP_CIPHER_CTX ctx;
	EVP_CIPHER_CTX_init(&ctx);
	ret = EVP_DecryptInit_ex(&ctx, EVP_aes_128_cbc(), NULL, RC_AES_KEY, RC_AES_IV);
    if(ret != 1) {
        log_error("%s: EVP_DecryptInit_ex failed!", __FUNCTION__);
        return -1;
    }

    EVP_CIPHER_CTX_set_padding(&ctx, AES_PADDING_EN);
    ret = EVP_DecryptUpdate(&ctx, pPlainOut, &de_data_len, pEncIn, encLength);
    if(ret != 1) {
        log_error("%s: EVP_DecryptUpdate failed!", __FUNCTION__);
        return -1;
    }

	ret = EVP_DecryptFinal_ex(&ctx, pPlainOut + de_data_len, &de_pad_len);
    if(ret != 1) {
        log_error("%s: EVP_DecryptFinal_ex failed!", __FUNCTION__);
        return -1;
    }

	EVP_CIPHER_CTX_cleanup(&ctx);
	return de_data_len + de_pad_len;
}

int main(void)
{
	int ret;
	uint8_t envOut[256] = { 0 };
	ret = aes_encrypt(planText2, strlen(planText2), envOut, sizeof(envOut));
	log_info("aes_encrypt len: %d", ret);
	dump(envOut, ret);

	uint8_t plainOut[256] = { 0 };
	ret = aes_decrypt(envOut, ret, plainOut, sizeof(plainOut));
	log_info("\naes_decrypt len: %d", ret);
	log_info("plainOut: %s", plainOut);
	return 0;
}

