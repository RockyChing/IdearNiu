#include <stdio.h>
#include <string.h>
#include <assert.h>

#include <aes/aes.h>
#include <aes/evp.h>
#include <aes/mem.h>

#define STRICT_ALIGNMENT 0

typedef struct {
	AES_KEY ks;
	block128_f block;
	union {
		cbc128_f cbc;
	} stream;
} EVP_AES_KEY;

#if 0
#define OPENSSL_VERSION_NUMBER	0x1000106fL
const char AES_version[]="AES from OpenSSL 1.0.1f 6 Jan 2014";

const char *AES_options(void) {
#ifdef FULL_UNROLL
        return "aes(full)";
#else   
        return "aes(partial)";
#endif
}
#endif

void CRYPTO_cbc128_encrypt(const unsigned char *in, unsigned char *out,
			size_t len, const void *key,
			unsigned char ivec[16], block128_f block)
{
	size_t n;
	const unsigned char *iv = ivec;

	assert(in && out && key && ivec);

#if !defined(OPENSSL_SMALL_FOOTPRINT)
	if (STRICT_ALIGNMENT &&
	    ((size_t)in|(size_t)out|(size_t)ivec)%sizeof(size_t) != 0) {
		while (len>=16) {
			for(n=0; n<16; ++n)
				out[n] = in[n] ^ iv[n];
			(*block)(out, out, key);
			iv = out;
			len -= 16;
			in  += 16;
			out += 16;
		}
	} else {
		while (len>=16) {
			for(n=0; n<16; n+=sizeof(size_t))
				*(size_t*)(out+n) =
				*(size_t*)(in+n) ^ *(size_t*)(iv+n);
			(*block)(out, out, key);
			iv = out;
			len -= 16;
			in  += 16;
			out += 16;
		}
	}
#endif
	while (len) {
		for(n=0; n<16 && n<len; ++n)
			out[n] = in[n] ^ iv[n];
		for(; n<16; ++n)
			out[n] = iv[n];
		(*block)(out, out, key);
		iv = out;
		if (len<=16) break;
		len -= 16;
		in  += 16;
		out += 16;
	}
	memcpy(ivec,iv,16);
}

void CRYPTO_cbc128_decrypt(const unsigned char *in, unsigned char *out,
			size_t len, const void *key,
			unsigned char ivec[16], block128_f block)
{
	size_t n;
	union { size_t t[16/sizeof(size_t)]; unsigned char c[16]; } tmp;

	assert(in && out && key && ivec);

#if !defined(OPENSSL_SMALL_FOOTPRINT)
	if (in != out) {
		const unsigned char *iv = ivec;

		if (STRICT_ALIGNMENT &&
		    ((size_t)in|(size_t)out|(size_t)ivec)%sizeof(size_t) != 0) {
			while (len>=16) {
				(*block)(in, out, key);
				for(n=0; n<16; ++n)
					out[n] ^= iv[n];
				iv = in;
				len -= 16;
				in  += 16;
				out += 16;
			}
		}
		else  if (16%sizeof(size_t) == 0) { /* always true */
			while (len>=16) {
				size_t *out_t=(size_t *)out, *iv_t=(size_t *)iv;

				(*block)(in, out, key);
				for(n=0; n<16/sizeof(size_t); n++)
					out_t[n] ^= iv_t[n];
				iv = in;
				len -= 16;
				in  += 16;
				out += 16;
			}
		}
		memcpy(ivec,iv,16);
	} else {
		if (STRICT_ALIGNMENT &&
		    ((size_t)in|(size_t)out|(size_t)ivec)%sizeof(size_t) != 0) {
			unsigned char c;
			while (len>=16) {
				(*block)(in, tmp.c, key);
				for(n=0; n<16; ++n) {
					c = in[n];
					out[n] = tmp.c[n] ^ ivec[n];
					ivec[n] = c;
				}
				len -= 16;
				in  += 16;
				out += 16;
			}
		}
		else if (16%sizeof(size_t) == 0) { /* always true */
			while (len>=16) {
				size_t c, *out_t=(size_t *)out, *ivec_t=(size_t *)ivec;
				const size_t *in_t=(const size_t *)in;

				(*block)(in, tmp.c, key);
				for(n=0; n<16/sizeof(size_t); n++) {
					c = in_t[n];
					out_t[n] = tmp.t[n] ^ ivec_t[n];
					ivec_t[n] = c;
				}
				len -= 16;
				in  += 16;
				out += 16;
			}
		}
	}
#endif
	while (len) {
		unsigned char c;
		(*block)(in, tmp.c, key);
		for(n=0; n<16 && n<len; ++n) {
			c = in[n];
			out[n] = tmp.c[n] ^ ivec[n];
			ivec[n] = c;
		}
		if (len<=16) {
			for (; n<16; ++n)
				ivec[n] = in[n];
			break;
		}
		len -= 16;
		in  += 16;
		out += 16;
	}
}

int AES_set_encrypt_key(const unsigned char *userKey, const int bits,
			AES_KEY *key)
{
	return private_AES_set_encrypt_key(userKey, bits, key);
}

int AES_set_decrypt_key(const unsigned char *userKey, const int bits,
			AES_KEY *key)
{
	return private_AES_set_decrypt_key(userKey, bits, key);
}

void AES_cbc_encrypt(const unsigned char *in, unsigned char *out,
			 size_t len, const AES_KEY *key,
			 unsigned char *ivec, const int enc) {

	if (enc)
		CRYPTO_cbc128_encrypt(in,out,len,key,ivec,(block128_f)AES_encrypt);
	else
		CRYPTO_cbc128_decrypt(in,out,len,key,ivec,(block128_f)AES_decrypt);
}

static int aes_init_key(EVP_CIPHER_CTX *ctx, const unsigned char *key,
		   const unsigned char *iv, int enc)
{
	int ret, mode;
	EVP_AES_KEY *dat = (EVP_AES_KEY *)ctx->cipher_data;

	mode = ctx->cipher->flags & EVP_CIPH_MODE;
	if ((mode == EVP_CIPH_ECB_MODE || mode == EVP_CIPH_CBC_MODE)
		&& !enc) {
		ret = AES_set_decrypt_key(key,ctx->key_len*8,&dat->ks);
		dat->block	= (block128_f)AES_decrypt;
		dat->stream.cbc = mode==EVP_CIPH_CBC_MODE ?
					(cbc128_f)AES_cbc_encrypt :
					NULL;
	} else {
		ret = AES_set_encrypt_key(key,ctx->key_len*8,&dat->ks);
		dat->block	= (block128_f)AES_encrypt;
		dat->stream.cbc = mode==EVP_CIPH_CBC_MODE ?
					(cbc128_f)AES_cbc_encrypt :
					NULL;
	}

	if(ret < 0) {
		return 0;
	}

	return 1;
}

static int aes_cbc_cipher(EVP_CIPHER_CTX *ctx,unsigned char *out,
	const unsigned char *in, size_t len)
{
	EVP_AES_KEY *dat = (EVP_AES_KEY *)ctx->cipher_data;

	if (dat->stream.cbc)
		(*dat->stream.cbc)(in,out,len,&dat->ks,ctx->iv,ctx->encrypt);
	else if (ctx->encrypt)
		CRYPTO_cbc128_encrypt(in,out,len,&dat->ks,ctx->iv,dat->block);
	else
		CRYPTO_cbc128_encrypt(in,out,len,&dat->ks,ctx->iv,dat->block);

	return 1;
}

static const EVP_CIPHER aes_128_cbc = {
	0, 16, 16, 16,
	EVP_CIPH_CBC_MODE,
	aes_init_key,
	aes_cbc_cipher,
	NULL,
	sizeof(EVP_AES_KEY),
	NULL
};

const EVP_CIPHER *EVP_aes_128_cbc(void)
{
	return &aes_128_cbc;
}

