#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <aes/mem.h>

/* the following pointers may be changed as long as 'allow_customize' is set */

static void *(*malloc_func)(size_t)         = malloc;
static void *default_malloc_ex(size_t num, const char *file, int line)
	{ return malloc_func(num); }
static void *(*malloc_ex_func)(size_t, const char *file, int line)
        = default_malloc_ex;

static void *(*realloc_func)(void *, size_t)= realloc;
static void *default_realloc_ex(void *str, size_t num,
        const char *file, int line)
	{ return realloc_func(str,num); }
static void *(*realloc_ex_func)(void *, size_t, const char *file, int line)
        = default_realloc_ex;

static void (*free_func)(void *)            = free;

static void *(*malloc_locked_func)(size_t)  = malloc;
static void *default_malloc_locked_ex(size_t num, const char *file, int line)
	{ return malloc_locked_func(num); }
//static void *(*malloc_locked_ex_func)(size_t, const char *file, int line)
//        = default_malloc_locked_ex;

static void (*free_locked_func)(void *)     = free;

void CRYPTO_free_locked(void *str)
{
	free_locked_func(str);
}

void *CRYPTO_malloc(int num, const char *file, int line)
{
	void *ret = NULL;

	if (num <= 0) return NULL;

	ret = malloc_ex_func(num,file,line);
	return ret;
}

char *CRYPTO_strdup(const char *str, const char *file, int line)
{
	char *ret = CRYPTO_malloc(strlen(str)+1, file, line);

	strcpy(ret, str);
	return ret;
}

void *CRYPTO_realloc(void *str, int num, const char *file, int line)
{
	void *ret = NULL;
	if (str == NULL)
		return CRYPTO_malloc(num, file, line);

	if (num <= 0) return NULL;

	ret = realloc_ex_func(str,num,file,line);
	return ret;
}

void *CRYPTO_realloc_clean(void *str, int old_len, int num, const char *file,
			   int line)
{
	void *ret = NULL;
	if (str == NULL)
		return CRYPTO_malloc(num, file, line);

	if (num <= 0) return NULL;

	/* We don't support shrinking the buffer. Note the memcpy that copies
	 * |old_len| bytes to the new buffer, below. */
	if (num < old_len) return NULL;

	ret = malloc_ex_func(num,file,line);
	if(ret) {
		memcpy(ret,str,old_len);
		OPENSSL_cleanse(str,old_len);
		free_func(str);
	}

	return ret;
}

void CRYPTO_free(void *str)
{
	free_func(str);
}

void *CRYPTO_remalloc(void *a, int num, const char *file, int line)
{
	if (a != NULL) OPENSSL_free(a);
	a=(char *)OPENSSL_malloc(num);
	return(a);
}

unsigned char cleanse_ctr = 0;

void OPENSSL_cleanse(void *ptr, size_t len)
{
	unsigned char *p = ptr;
	size_t loop = len, ctr = cleanse_ctr;
	while(loop--) {
		*(p++) = (unsigned char)ctr;
		ctr += (17 + ((size_t)p & 0xF));
	}

	p=memchr(ptr, (unsigned char)ctr, len);
	if(p)
		ctr += (63 + (size_t)p);

	cleanse_ctr = (unsigned char)ctr;
}

